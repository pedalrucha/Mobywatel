import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { Document } from '../models/Document';

type DocumentCardProps = {
  document: Document;
  onPress: (document: Document) => void;
};

function DocumentCard({ document, onPress }: DocumentCardProps) {
  return (
    <Pressable style={styles.card} onPress={() => onPress(document)}>
      <View style={[styles.icon, { backgroundColor: document.accentColor }]} />
      <View style={styles.content}>
        <Text style={styles.title}>{document.title}</Text>
        <Text style={styles.description}>{document.description}</Text>
      </View>
      <Text style={styles.chevron}>{'>'}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#122033',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.08,
    shadowRadius: 16,
    elevation: 2,
  },
  icon: {
    width: 42,
    height: 42,
    borderRadius: 12,
    marginRight: 14,
  },
  content: {
    flex: 1,
  },
  title: {
    fontSize: 17,
    fontWeight: '700',
    color: '#1F2937',
    marginBottom: 4,
  },
  description: {
    fontSize: 13,
    lineHeight: 18,
    color: '#6B7280',
  },
  chevron: {
    fontSize: 24,
    color: '#9CA3AF',
    marginLeft: 12,
  },
});

export default DocumentCard;
