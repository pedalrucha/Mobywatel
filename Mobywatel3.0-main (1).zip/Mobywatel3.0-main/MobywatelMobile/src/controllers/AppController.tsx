import React, { useState } from 'react';

import { documents } from '../data/documents';
import { Document } from '../models/Document';
import DocumentDetailsView from '../views/DocumentDetailsView';
import HomeView from '../views/HomeView';

function AppController() {
  const [selectedDocument, setSelectedDocument] = useState<Document | null>(null);

  if (selectedDocument) {
    return (
      <DocumentDetailsView
        document={selectedDocument}
        onBack={() => setSelectedDocument(null)}
      />
    );
  }

  return (
    <HomeView
      documents={documents}
      onSelectDocument={setSelectedDocument}
    />
  );
}

export default AppController;
