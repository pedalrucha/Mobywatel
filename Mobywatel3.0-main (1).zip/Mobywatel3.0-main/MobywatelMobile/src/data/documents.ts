import { Document } from '../models/Document';

export const documents: Document[] = [
  {
    id: 'mdowod',
    title: 'mDowod',
    description: 'Prawnie wazny elektroniczny dokument tozsamosci.',
    status: 'valid',
    accentColor: '#E84D5B',
  },
  {
    id: 'diia',
    title: 'Diia',
    description: 'Elektroniczny dokument tozsamosci obywateli Ukrainy.',
    status: 'new',
    accentColor: '#3A7DFF',
  },
  {
    id: 'student-card',
    title: 'Legitymacja studencka',
    description: 'Elektroniczny dokument potwierdzajacy status studenta.',
    status: 'new',
    accentColor: '#36B6D6',
  },
];
