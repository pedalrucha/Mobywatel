import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';

import DocumentCard from '../components/DocumentCard';
import { Document } from '../models/Document';

type HomeViewProps = {
  documents: Document[];
  onSelectDocument: (document: Document) => void;
};

function HomeView({ documents, onSelectDocument }: HomeViewProps) {
  return (
    <ScrollView contentContainerStyle={styles.content} style={styles.screen}>
      <View style={styles.hero}>
        <View style={styles.heroIcon} />
        <Text style={styles.heroTitle}>Dodaj pierwszy dokument</Text>
        <Text style={styles.heroDescription}>
          Zacznij od jednego dokumentu. Potem rozbudujesz aplikacje o kolejne
          widoki i funkcje
        </Text>
      </View>

      <Text style={styles.sectionTitle}>Twoje dokumenty</Text>

      {documents.map(document => (
        <DocumentCard
          key={document.id}
          document={document}
          onPress={onSelectDocument}
        />
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#F4F7FB',
  },
  content: {
    padding: 20,
    paddingTop: 24,
  },
  hero: {
    backgroundColor: '#FFFFFF',
    borderRadius: 28,
    padding: 24,
    alignItems: 'center',
    marginBottom: 24,
    shadowColor: '#122033',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.08,
    shadowRadius: 20,
    elevation: 2,
  },
  heroIcon: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: '#D9EAFE',
    marginBottom: 16,
  },
  heroTitle: {
    fontSize: 28,
    fontWeight: '800',
    color: '#111827',
    textAlign: 'center',
    marginBottom: 10,
  },
  heroDescription: {
    fontSize: 15,
    lineHeight: 22,
    color: '#6B7280',
    textAlign: 'center',
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#111827',
    marginBottom: 12,
  },
});

export default HomeView;
