import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import PrimaryButton from '../components/PrimaryButton';
import { Document } from '../models/Document';

type DocumentDetailsViewProps = {
  document: Document;
  onBack: () => void;
};

function DocumentDetailsView({
  document,
  onBack,
}: DocumentDetailsViewProps) {
  return (
    <View style={styles.screen}>
      <Pressable onPress={onBack}>
        <Text style={styles.backButton}>Wroc</Text>
      </Pressable>

      <Text style={styles.title}>{document.title}</Text>
      <Text style={styles.subtitle}>Szczegoly dokumentu</Text>

      <View style={styles.previewCard}>
        <View style={[styles.previewAccent, { backgroundColor: document.accentColor }]} />
        <Text style={styles.previewName}>ANATOL KRZYSZTOF</Text>
        <Text style={styles.previewLabel}>Imie i nazwisko</Text>
        <Text style={styles.previewValue}>85120500779</Text>
        <Text style={styles.previewLabel}>Numer PESEL</Text>
        <Text style={styles.previewStatus}>
          Status: {document.status === 'valid' ? 'Dokument wazny' : 'Nowy dokument'}
        </Text>
      </View>

      <View style={styles.actions}>
        <PrimaryButton label="Pokaz dane" onPress={() => {}} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#F4F7FB',
    padding: 20,
    paddingTop: 24,
  },
  backButton: {
    fontSize: 18,
    color: '#0B63CE',
    marginBottom: 24,
  },
  title: {
    fontSize: 30,
    fontWeight: '800',
    color: '#111827',
  },
  subtitle: {
    fontSize: 15,
    color: '#6B7280',
    marginTop: 6,
    marginBottom: 20,
  },
  previewCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 28,
    padding: 20,
    shadowColor: '#122033',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.08,
    shadowRadius: 20,
    elevation: 2,
  },
  previewAccent: {
    height: 110,
    borderRadius: 20,
    marginBottom: 20,
    opacity: 0.18,
  },
  previewName: {
    fontSize: 24,
    fontWeight: '800',
    color: '#111827',
  },
  previewLabel: {
    fontSize: 13,
    color: '#6B7280',
    marginTop: 8,
  },
  previewValue: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1F2937',
    marginTop: 2,
  },
  previewStatus: {
    marginTop: 20,
    fontSize: 15,
    fontWeight: '700',
    color: '#4B5563',
  },
  actions: {
    marginTop: 24,
  },
});

export default DocumentDetailsView;
