export type DocumentStatus = 'valid' | 'new';

export type Document = {
  id: string;
  title: string;
  description: string;
  status: DocumentStatus;
  accentColor: string;
};
